function [x, eps] = generate_ARMA(T, sigma2, AR_input, MA_input, isRoot)
% ---------------------------------------------------------------
% Generates T observations from an ARMA(p,q) process
%
%   x_t = sum_{i=1}^p phi_i * x_{t-i} + eps_t
%         + sum_{j=1}^q theta_j * eps_{t-j}
%
% Inputs:
%   T          - number of observations
%   sigma2     - innovation variance
%   AR_input   - AR coefficients or roots
%   MA_input   - MA coefficients or roots
%   isRoot     - = true if inputs are roots, = false (default) if coefficients
%
% Outputs:
%   x   - simulated ARMA(p,q) series
%   eps - white noise innovations
% ---------------------------------------------------------------

if nargin < 5
    isRoot = false;  % default: interpret as coefficients
end

% --- Convert roots to coefficients if needed ---
if isRoot
    % AR polynomial: A(L) = prod_i (1 - λ_i L) = 1 - φ₁L - ... - φ_pL^p
    if ~isempty(AR_input)
        polyA = 1;
        for i = 1:length(AR_input)
            polyA = conv(polyA, [1, -AR_input(i)]);
        end
        ARcoeff = -polyA(2:end);
    else
        ARcoeff = [];
    end

    % MA polynomial: B(L) = prod_j (1 + λ_j L) = 1 + θ₁L + ... + θ_qL^q
    if ~isempty(MA_input)
        polyB = 1;
        for j = 1:length(MA_input)
            polyB = conv(polyB, [1, MA_input(j)]);
        end
        MAcoeff = polyB(2:end);
    else
        MAcoeff = [];
    end
else
    ARcoeff = AR_input(:)';   % ensure row vector
    MAcoeff = MA_input(:)';
end

% --- Orders and burn-in ---
p = length(ARcoeff);
q = length(MAcoeff);
burnin = 200;
N = T + burnin;

% --- Allocate and simulate ---
x_full   = zeros(N,1);
eps_full = sqrt(sigma2) * randn(N,1);

for t = 1:N
    % AR part
    for i = 1:p
        if t - i > 0
            x_full(t) = x_full(t) + ARcoeff(i) * x_full(t - i);
        end
    end
    % MA part
    for j = 1:q
        if t - j > 0
            x_full(t) = x_full(t) + MAcoeff(j) * eps_full(t - j);
        end
    end
    % Innovation
    x_full(t) = x_full(t) + eps_full(t);
end

% --- Drop burn-in period ---
x   = x_full(burnin+1:end);
eps = eps_full(burnin+1:end);

end
